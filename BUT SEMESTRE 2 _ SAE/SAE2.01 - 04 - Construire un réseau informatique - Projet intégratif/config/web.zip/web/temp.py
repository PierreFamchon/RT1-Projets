import os
import serial
import time
import socket
import mysql.connector

# Configuration du port série
ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
time.sleep(2)  # Donne du temps à l'Arduino pour redémarrer

# Configuration de la base de données MySQL
config = {
    'user': 'root',
    'password': 'progtr00',
    'host': 'localhost',
    'database': 'pepiniere',
    'raise_on_warnings': True
}

# Adresse IP spécifique à utiliser
IP_ADDRESS = '192.168.30.3'

# Fonction pour récupérer l'adresse IP actuelle
def get_current_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip_address = s.getsockname()[0]
        s.close()
        print(f"Assigned IP: {ip_address}")
        return ip_address
    except Exception as e:
        print(f"Could not configure network: {e}")
        return None

def connect_to_database():
    try:
        conn = mysql.connector.connect(**config)
        print("Connected to MySQL database")
        return conn
    except mysql.connector.Error as err:
        print(f"Error connecting to MySQL database: {err}")
        return None

# Créer une table pour les données de température et d'humidité
def create_table(conn):
    if not conn:
        print("Database connection not established. Cannot create table.")
        return
    
    try:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS arduino (
                id INT AUTO_INCREMENT PRIMARY KEY,
                temperature FLOAT,
                humidity FLOAT,
                ip VARCHAR(50),
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("Created table arduino")
    except mysql.connector.Error as err:
        print(f"Error creating table in MySQL database: {err}")

# Insérer les données dans la base de données
def insert_into_database(conn, temperature, humidity, ip_address):
    if not conn:
        print("Database connection not established. Cannot insert data.")
        return
    
    try:
        cursor = conn.cursor()
        sql = "INSERT INTO arduino (temperature, humidity, ip) VALUES (%s, %s, %s)"
        cursor.execute(sql, (temperature, humidity, ip_address))
        conn.commit()
        print(f"Data inserted into database: Temperature={temperature} C, Humidity={humidity} %, IP={ip_address}")
        cleanup_database(conn)  # Appel à la fonction pour nettoyer la base de données
    except mysql.connector.Error as err:
        print(f"Error inserting data into MySQL database: {err}")

# Lire les données du capteur
def read_sensor():
    try:
        line = ser.readline()
        line = line.decode('utf-8').rstrip()  # Essayer avec utf-8
    except UnicodeDecodeError:
        print("UnicodeDecodeError: Decoding with utf-8 failed. Trying different encoding...")
        try:
            line = line.decode('latin-1').rstrip()  # Essayer avec latin-1 (ISO-8859-1)
        except UnicodeDecodeError as e:
            print(f"UnicodeDecodeError: Failed to decode line. Error: {e}")
            return None, None

    if line.startswith('Temperature = ') and line.endswith(' C'):
        temperature = float(line.split(' = ')[1].split(' C')[0])
        line = ser.readline()
        try:
            line = line.decode('utf-8').rstrip()
        except UnicodeDecodeError:
            print("UnicodeDecodeError: Decoding with utf-8 failed for humidity. Trying different encoding...")
            try:
                line = line.decode('latin-1').rstrip()  # Essayer avec latin-1 (ISO-8859-1)
            except UnicodeDecodeError as e:
                print(f"UnicodeDecodeError: Failed to decode humidity line. Error: {e}")
                return None, None
            
        if line.startswith('Humidity = ') and line.endswith(' %'):
            humidity = float(line.split(' = ')[1].split(' %')[0])
            return temperature, humidity
    
    return None, None

# Fonction pour nettoyer la base de données (supprimer les entrées excédentaires)
def cleanup_database(conn):
    try:
        cursor = conn.cursor()
        # Compter le nombre d'entrées actuelles
        cursor.execute("SELECT COUNT(*) FROM arduino")
        count = cursor.fetchone()[0]
        
        # Si le nombre d'entrées dépasse 10, supprimer les plus anciennes
        if count > 10:
            delete_count = count - 10
            cursor.execute(f"DELETE FROM arduino ORDER BY timestamp LIMIT {delete_count}")
            conn.commit()
            print(f"Deleted {delete_count} oldest records from database")
    except mysql.connector.Error as err:
        print(f"Error cleaning up database: {err}")

def main():
    conn = connect_to_database()
    if not conn:
        return
    
    create_table(conn)
    
    while True:
        # Récupérer l'adresse IP actuelle toutes les 30 secondes
        IP_ADDRESS = get_current_ip()
        if IP_ADDRESS is None:
            time.sleep(30)  # Attendre 30 secondes avant de réessayer
            continue
        
        temperature, humidity = read_sensor()
        if temperature is not None and humidity is not None:
            insert_into_database(conn, temperature, humidity, IP_ADDRESS)
        
        time.sleep(30)  # Pause de 30 secondes avant la prochaine lecture

if __name__ == "__main__":
    main()

