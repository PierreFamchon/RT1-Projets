-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : db:3306
-- Généré le : mer. 21 juin 2023 à 09:30
-- Version du serveur : 8.0.33
-- Version de PHP : 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `pepiniere`
--

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

CREATE TABLE `services` (
  `id` int NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL,
  `categorie` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `services`
--

INSERT INTO `services` (`id`, `nom`, `description`, `prix`, `categorie`) VALUES
(1, 'Service de développement web', 'Création de sites web et d\'applications', 1000.00, 'Développement'),
(2, 'Service de design graphique', 'Conception de logos et de supports visuels', 500.00, 'Design'),
(3, 'Service de marketing numérique', 'Stratégies de marketing en ligne', 800.00, 'Marketing'),
(4, 'Service de conseil en affaires', 'Conseils pour optimiser la performance des entreprises', 1200.00, 'Conseil'),
(5, 'Service d\'hébergement web', 'Hébergement sécurisé pour les sites web', 200.00, 'Technologie');

-- --------------------------------------------------------

--
-- Structure de la table `services2`
--

CREATE TABLE `services2` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `services2`
--

INSERT INTO `services2` (`id`, `name`, `description`, `price`, `category`) VALUES
(1, 'Web Development Service', 'Creation of websites and applications', 1000.00, 'Development'),
(2, 'Graphic Design Service', 'Design of logos and visual media', 500.00, 'Design'),
(3, 'Digital Marketing Service', 'Online marketing strategies', 800.00, 'Marketing'),
(4, 'Business Consulting Service', 'Advice for optimizing business performance', 1200.00, 'Consulting'),
(5, 'Web Hosting Service', 'Secure hosting for websites', 200.00, 'Technology');

--
-- Index pour les tables déchargées
--
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



INSERT INTO `users` (`username`, `password`) VALUES
('admin', '$2b$12$nxq1/UzknIv3AlnZIYP6sejQAdR4y85Js1yYbHNYtWRujA1AN0PNO'), 
('root', '$2b$12$nxq1/UzknIv3AlnZIYP6sejQAdR4y85Js1yYbHNYtWRujA1AN0PNO');


-- Structure de la table `arduino`
CREATE TABLE IF NOT EXISTS arduino (
    id INT AUTO_INCREMENT PRIMARY KEY,
    temperature FLOAT,
    humidity FLOAT,
    ip VARCHAR(50),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
--


-- Index pour la table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `services2`
--
ALTER TABLE `services2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `services`
--
ALTER TABLE `services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `services2`
--
ALTER TABLE `services2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
