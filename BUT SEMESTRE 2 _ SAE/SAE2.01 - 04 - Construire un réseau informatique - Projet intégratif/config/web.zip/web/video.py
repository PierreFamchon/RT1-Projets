import cv2
import numpy as np
from pyzbar.pyzbar import decode
import datetime
import mysql.connector

# Fonction pour écrire les données dans la base de données MySQL
def write_to_database(qr_data):
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="progtr00",
            database="pepiniere"  # Remplacez par le nom de votre base de données
        )
        
        cursor = connection.cursor()
        
        # Exécutez l'insertion dans la base de données
        sql = "INSERT INTO qrcodes (timestamp, data) VALUES (%s, %s)"
        now = datetime.datetime.now()
        timestamp = now.strftime('%Y-%m-%d %H:%M:%S')
        insert_data = (timestamp, qr_data)
        cursor.execute(sql, insert_data)
        
        # Valider la transaction
        connection.commit()
        print("Données insérées dans la base de données avec succès")
        
    except mysql.connector.Error as error:
        print("Erreur lors de l'insertion dans la base de données:", error)
        
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("Connexion à la base de données fermée")

# Fonction pour détecter et reconnaître les QR codes
def detect_and_recognize(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Détection de QR-codes
    decoded_objects = decode(gray)
    for obj in decoded_objects:
        points = obj.polygon
        if len(points) == 4:
            pts = np.array(points, dtype=np.int32)
            pts = pts.reshape((-1, 1, 2))
            cv2.polylines(frame, [pts], True, (0, 255, 0), 2)
            qr_data = obj.data.decode("utf-8")
            cv2.putText(frame, qr_data, (pts[0][0][0], pts[0][0][1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            print("QR Code Data:", qr_data)
            
            # Écrire les données du QR code dans la base de données
            write_to_database(qr_data)
            
            # Enregistrer les données du QR code dans un fichier
            with open("qrcodes.txt", "a") as f:
                f.write(f"{datetime.datetime.now()} - {qr_data}\n")
    
    return frame

# Capturer le flux vidéo MJPEG
mjpeg_url = 'http://192.168.20.12/video.mjpg'
cap = cv2.VideoCapture(mjpeg_url)

# Vérifier si la capture a été initialisée correctement
if not cap.isOpened():
    print("Erreur de connexion au flux MJPEG")
    exit()

while True:
    ret, frame = cap.read()
    if not ret:
        print("Erreur de lecture du flux MJPEG")
        break
    
    # Redimensionner la frame à 1080x720
    frame = cv2.resize(frame, (1080, 720))
    
    frame = detect_and_recognize(frame)
    
    cv2.imshow('Video Stream', frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

