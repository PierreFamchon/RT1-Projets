from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
import os
import bcrypt
from contextlib import contextmanager
from functools import wraps

app = Flask(__name__)
app.secret_key = 'progtr00'

# Configuration de la connexion à la base de données
config = {
    'user': os.environ.get('DB_USER'),
    'password': os.environ.get('DB_PASS'),
    'host': os.environ.get('DB_HOST'),
    'database': 'pepiniere',  # Assurez-vous que le nom de la base de données est correct
    'raise_on_warnings': True
}

@contextmanager
def connect_to_db():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()
    try:
        yield cursor, conn
    finally:
        cursor.close()
        conn.close()

def get_services(table_name):
    with connect_to_db() as (cursor, conn):
        cursor.execute(f"SELECT * FROM {table_name}")
        services = cursor.fetchall()
        print(services)  # Debugging line to see the fetched data
    return services

def submit_contact(name, email, message):
    try:
        with connect_to_db() as (cursor, conn):
            insert_query = "INSERT INTO contact_messages (name, email, message) VALUES (%s, %s, %s)"
            cursor.execute(insert_query, (name, email, message))
            conn.commit()
    except mysql.connector.Error as err:
        print("Erreur lors de l'insertion du message dans la base de données:", err)

def authenticate(username, password):
    try:
        with connect_to_db() as (cursor, conn):
            cursor.execute("SELECT password FROM users WHERE username = %s", (username,))
            hashed_password = cursor.fetchone()[0]  # Sélection du premier élément du tuple
            return check_password(password, hashed_password)
    except mysql.connector.Error as err:
        print("Erreur lors de l'authentification de l'utilisateur:", err)

def delete_message(id):
    try:
        with connect_to_db() as (cursor, conn):
            delete_query = "DELETE FROM contact_messages WHERE id = %s"
            cursor.execute(delete_query, (id,))
            conn.commit()
    except mysql.connector.Error as err:
        print("Erreur lors de la suppression du message :", err)

def add_service(table):
    try:
        with connect_to_db() as (cursor, conn):
            if table == 'services':
                insert_query = "INSERT INTO services (nom, description, prix, categorie) VALUES (%s, %s, %s, %s)"
                cursor.execute(insert_query, ("Nouveau service", "Description du nouveau service", 0, "Nouvelle catégorie"))
            elif table == 'services2':
                insert_query = "INSERT INTO services2 (name, description, price, category) VALUES (%s, %s, %s, %s)"
                cursor.execute(insert_query, ("New service", "Description of the new service", 0, "New category"))
            conn.commit()
    except mysql.connector.Error as err:
        print("Erreur lors de l'ajout du service dans la base de données:", err)

def get_temperature_humidity():
    try:
        with connect_to_db() as (cursor, conn):
            cursor.execute("SELECT temperature, humidity, timestamp FROM arduino ORDER BY timestamp DESC LIMIT 10")
            data = cursor.fetchall()
        return data
    except mysql.connector.Error as err:
        print("Erreur lors de la récupération des données de température et d'humidité:", err)

def delete_service(table, id):
    try:
        with connect_to_db() as (cursor, conn):
            if table == 'services':
                delete_query = "DELETE FROM services WHERE id = %s"
            elif table == 'services2':
                delete_query = "DELETE FROM services2 WHERE id = %s"
            cursor.execute(delete_query, (id,))
            conn.commit()
    except mysql.connector.Error as err:
        print("Erreur lors de la suppression du service :", err)

def update_service(table, id, name, description, price, category):
    try:
        with connect_to_db() as (cursor, conn):
            if table == 'services':
                update_query = "UPDATE services SET nom = %s, description = %s, prix = %s, categorie = %s WHERE id = %s"
            elif table == 'services2':
                update_query = "UPDATE services2 SET name = %s, description = %s, price = %s, category = %s WHERE id = %s"
            cursor.execute(update_query, (name, description, price, category, id))
            conn.commit()
    except mysql.connector.Error as err:
        print("Erreur lors de la mise à jour du service dans la base de données:", err)

def hash_password(password: str) -> bytes:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def check_password(password: str, hashed: bytes) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login3'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def home():
    title = "Paris - Société 5"
    services = get_services('services')
    print(services)  # Debugging line to see the data before rendering
    return render_template('index.html', title=title, services=services)

@app.route('/en')
def home2():
    title = "Paris - Company 5"
    services = get_services('services2')
    return render_template('index2.html', title=title, services=services)

@app.route('/submit_contact', methods=['POST'])
def contact_submit():
    name = request.form.get('name')
    email = request.form.get('email')
    message = request.form.get('message')
    submit_contact(name, email, message)
    return redirect(url_for('home'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if authenticate(username, password):
            session['username'] = username
            return redirect(url_for('view_tables'))
    return render_template('login.html')

@app.route('/login3', methods=['GET', 'POST'])
def login3():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if authenticate(username, password):
            session['username'] = username
            return redirect(url_for('video'))
        else:
            error = 'Invalid credentials. Please try again.'
            return render_template('login3.html', error=error)
    return render_template('login3.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login3'))

@app.route('/video')
@login_required
def video():
    return render_template('video.html')

@app.route('/view_tables')
def view_tables():
    if 'username' not in session:
        return redirect(url_for('login'))
    tables_content = {}
    try:
        with connect_to_db() as (cursor, conn):
            cursor.execute("SHOW TABLES")
            tables = [table[0] for table in cursor.fetchall()]
            for table in tables:
                cursor.execute(f"SELECT * FROM {table}")
                tables_content[table] = cursor.fetchall()
    except mysql.connector.Error as err:
        print("Erreur lors de la récupération des tables:", err)
    return render_template('tables.html', tables_content=tables_content)

def get_service(table, id):
    try:
        with connect_to_db() as (cursor, conn):
            if table == 'services':
                cursor.execute("SELECT * FROM services WHERE id = %s", (id,))
            elif table == 'services2':
                cursor.execute("SELECT * FROM services2 WHERE id = %s", (id,))
            service = cursor.fetchone()
        return service
    except mysql.connector.Error as err:
        print("Erreur lors de la récupération du service depuis la base de données:", err)

@app.route('/delete_message/<int:id>', methods=['POST'])
def delete_message_route(id):
    if 'username' not in session:
        return redirect(url_for('login'))
    delete_message(id)
    return redirect(url_for('view_tables'))

@app.route('/add_service/<table>', methods=['POST'])
def add_service_route(table):
    if 'username' not in session:
        return redirect(url_for('login'))
    add_service(table)
    return redirect(url_for('view_tables'))

@app.route('/temperature_data')
def temperature_data():
    try:
        data = get_temperature_humidity()
        return render_template('temp.html', title='Arduino Data', data=data)
    except Exception as e:
        print(f"Error fetching temperature and humidity data: {str(e)}")
        return "Error fetching data from database", 500

@app.route('/delete_service/<table>/<int:id>', methods=['POST'])
def delete_service_route(table, id):
    if 'username' not in session:
        return redirect(url_for('login'))
    delete_service(table, id)
    return redirect(url_for('view_tables'))

@app.route('/edit_service/<table>/<int:id>', methods=['GET', 'POST'])
def edit_service_route(table, id):
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        # Récupérer les données du formulaire de modification
        nom = request.form.get('nom')
        description = request.form.get('description')
        prix = request.form.get('prix')
        categorie = request.form.get('categorie')

        # Mettre à jour les valeurs dans la table "services"
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            update_query = "UPDATE services SET nom = %s, description = %s, prix = %s, categorie = %s WHERE id = %s"
            cursor.execute(update_query, (nom, description, prix, categorie, id))
            conn.commit()
        except mysql.connector.Error as err:
            print("Erreur lors de la modification du service dans la base de données:", err)
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

        return redirect(url_for('view_tables'))
    else:
        service = get_service(table, id)
        return render_template('edit_service.html', table=table, service=service)

@app.route('/edit_service2/<table>/<int:id>', methods=['GET', 'POST'])
def edit_service2_route(table, id):
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        # Récupérer les données du formulaire de modification
        name = request.form.get('name')
        description = request.form.get('description')
        price = request.form.get('price')
        category = request.form.get('category')

        # Mettre à jour les valeurs dans la table "services2"
        try:
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()
            update_query = "UPDATE services2 SET name = %s, description = %s, price = %s, category = %s WHERE id = %s"
            cursor.execute(update_query, (name, description, price, category, id))
            conn.commit()
        except mysql.connector.Error as err:
            print("Erreur lors de la modification du service dans la base de données:", err)
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

        return redirect(url_for('view_tables'))
    else:
        service = get_service(table, id)
        return render_template('edit_service2.html', table=table, service=service)

@app.route('/update_service/<table>/<int:id>', methods=['POST'])
def update_service_route(table, id):
    if 'username' not in session:
        return redirect(url_for('login'))
    name = request.form.get('name')
    description = request.form.get('description')
    price = request.form.get('price')
    category = request.form.get('category')
    update_service(table, id, name, description, price, category)
    return redirect(url_for('view_tables'))

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80)

